// Fill out your copyright notice in the Description page of Project Settings.


#include "MainWidget.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"
#include "HockeyPauseWidget.h"

void UMainWidget::PressPauseButton()
{
	UGameplayStatics::SetGamePaused(GetWorld(), true);
	if (pauseWidget != nullptr)
	{
		pauseUI = CreateWidget<UHockeyPauseWidget>(GetWorld(), pauseWidget);
		if (pauseUI != nullptr)
		{
			pauseUI->AddToViewport();
		}
	}
}

void UMainWidget::NativeConstruct()
{
	Super::NativeConstruct();
	PauseButton->OnClicked.AddDynamic(this, &UMainWidget::PressPauseButton);
}
