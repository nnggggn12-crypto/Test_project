// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HockeyPauseWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UHockeyPauseWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* ResumeButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* RetryButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* StopAndExitButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* OptionButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* XButton;

	UPROPERTY(EditAnywhere)
	TSubclassOf<class UOptionPanelWidget> optionPanelWidget;
	UPROPERTY(EditAnywhere)
	class UOptionPanelWidget* optionPanelUI;

	UFUNCTION()
	void PressResumeButton();
	UFUNCTION()
	void PressRetryButton();
	UFUNCTION()
	void PressStopAndExitButton();
	UFUNCTION()
	void PressOptionButton();

private:
	virtual void NativeConstruct() override;

};
