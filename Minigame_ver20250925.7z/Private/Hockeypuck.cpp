// Fill out your copyright notice in the Description page of Project Settings.


#include "Hockeypuck.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "EngineUtils.h"
#include "PlayerPawn.h"
#include "HockeyEnemyChar.h"


// Sets default values
AHockeypuck::AHockeypuck()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	sphereComp = CreateDefaultSubobject<USphereComponent>(TEXT("MyComponent"));
	SetRootComponent(sphereComp);

	meshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MyStaticMesh"));
	meshComp->SetWorldScale3D(FVector(0.6f));
	meshComp->SetupAttachment(sphereComp);

	blockSpeed = 800;

}

// Called when the game starts or when spawn.ed
void AHockeypuck::BeginPlay()
{
	Super::BeginPlay();
	sphereComp->OnComponentBeginOverlap.AddDynamic(this, &AHockeypuck::OnPlayerHit);
	computergroundtick = 0.0f;
	playergroundtick = 0.0f;
	groundswitch = true;
}

// Called every frame
void AHockeypuck::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	FVector myLocation = GetActorLocation() + dir * blockSpeed * DeltaTime;
	myLocation.Z = 0;

	if (myLocation.Y <= 150 && myLocation.Y >= -150)
	{

	}
	else if (myLocation.X >= 920 && dir.X >= 0)
	{
		dir.X *= -1;
	}
	else if (myLocation.X <= -920 && dir.X <= 0)
	{
		dir.X *= -1;
	}
	if (myLocation.Y <= 150 && myLocation.Y >= -150)
	{
		
	}
	else if (myLocation.Y >= 500 && dir.Y >= 0)
	{
		dir.Y *= -1;
	}
	else if (myLocation.Y <= -500 && dir.Y <= 0)
	{
		dir.Y *= -1;
	}

	SetActorLocation(myLocation);

	if (groundswitch)
	{
		if (myLocation.X > 0)
		{
			computergroundtick += 0.1;
		}
		else if (myLocation.X < 0)
		{
			playergroundtick += 0.1;
		}
	}

	if (blockSpeed <= 2000)
	{
		blockSpeed += 0.1f;
	}

}

void AHockeypuck::OnPlayerHit(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	APlayerPawn* player = Cast<APlayerPawn>(OtherActor);
	AHockeyEnemyChar* Enemy = Cast<AHockeyEnemyChar>(OtherActor);

	if (player != nullptr)
	{
		dir = GetActorLocation() - player->GetActorLocation();
		dir.Normalize();
	}
	if (Enemy != nullptr)
	{
		dir = GetActorLocation() - Enemy->GetActorLocation();
		dir.Normalize();
	}
}

void AHockeypuck::increase_dirX(float _amount)
{
	direction_x = _amount;
}

void AHockeypuck::increase_dirY(float _amount)
{
	direction_y = _amount;
}

