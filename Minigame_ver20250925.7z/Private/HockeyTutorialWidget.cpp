// Fill out your copyright notice in the Description page of Project Settings.


#include "HockeyTutorialWidget.h"
#include "Components/Image.h"	
#include "Components/Button.h"

UHockeyTutorialWidget::UHockeyTutorialWidget(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

void UHockeyTutorialWidget::pressLeftButton()
{
	if (HockeyTutorialImageNumber > 1)
	{
		--HockeyTutorialImageNumber;
		changeImageState();
	}
}

void UHockeyTutorialWidget::pressRightButton()
{
	if (HockeyTutorialImageNumber < 4)
	{
		++HockeyTutorialImageNumber;
		changeImageState();
	}
}

void UHockeyTutorialWidget::changeImageState()
{
	//UImage* tutorialImage = Cast<UImage>(this->GetWidgetFromName(TEXT("HockeyTutorialImage")));
	UTexture2D* Image1 = LoadObject<UTexture2D>(nullptr, TEXT("/Script/Engine.Texture2D'/Game/HockeyAndMain/Image/background.background'"));
	UTexture2D* Image2 = LoadObject<UTexture2D>(nullptr, TEXT("/Script/Engine.Texture2D'/Game/HockeyAndMain/Image/background2.background2'"));


	switch (HockeyTutorialImageNumber)
	{
	case 1:
		if (Image1)
		{
			HockeyTutorialImage->SetBrushFromTexture(Image1);
		}
		break;
	case 2:
		if (Image2)
		{
			HockeyTutorialImage->SetBrushFromTexture(Image2);
		}
		break;
	case 3:
		break;
	case 4:
		break;
	}
}

void UHockeyTutorialWidget::NativeConstruct()
{
	Super::NativeConstruct();
	HockeyTutorialLeftButton->OnClicked.AddDynamic(this, &UHockeyTutorialWidget::pressLeftButton);
	HockeyTutorialRightButton->OnClicked.AddDynamic(this, &UHockeyTutorialWidget::pressRightButton);
}
