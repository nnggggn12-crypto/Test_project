// Fill out your copyright notice in the Description page of Project Settings.


#include "HocketpuckSpawner.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "PlayerPawn.h"
#include "Hockeypuck.h"
#include "Hockeybase.h"
#include "HockeyEnemyChar.h"

#include "Components/TextBlock.h"

// Sets default values
AHocketpuckSpawner::AHocketpuckSpawner()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	countdownText = CreateDefaultSubobject<UTextRenderComponent>(TEXT("COUNT"));
	countdownText->SetHorizontalAlignment(EHTA_Center);
	countdownText->SetWorldSize(150.0f);
	RootComponent = countdownText;


}

// Called when the game starts or when spawned
void AHocketpuckSpawner::BeginPlay()
{
	Super::BeginPlay();
	countdownText->SetText(FText::FromString(TEXT(" ")));
}

// Called every frame
void AHocketpuckSpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

//하키퍽을 000에 스폰시킴
void AHocketpuckSpawner::SpawnHockeypuck()
{
	FVector spawnlocation = FVector(0, 0, 0);
	FRotator spawnrotation = FRotator(0, 0, 0);
	FActorSpawnParameters spawnparam;
	spawnparam.bNoFail;
	AActor* spawnActor = GetWorld()->SpawnActor<AActor>(puck, spawnlocation, spawnrotation, spawnparam);
}

//타이머 디스플레이(5..4..3..2..1..)
void AHocketpuckSpawner::updateTimerdisplay()
{
	countdownText->SetText(FText::FromString(FString::FromInt(FMath::Max(countdownsec, 0))));
}

//타이머 함수
void AHocketpuckSpawner::AdvanceTimer()
{
	--countdownsec;
	updateTimerdisplay();
	if (countdownsec < 1)
	{

		// 카운트다운이 완료되면 타이머를 중지
		GetWorldTimerManager().ClearTimer(CountdownTimerHandle);
		CountdownHasFinished();
		countdownsec = 5;
		//이후 에너미 다시 활동 시작
		TActorIterator<AHockeyEnemyChar> Enemy(GetWorld());
		Enemy->EnemyMoveTrue();
		TActorIterator<AHockeybase> hockey(GetWorld());
		//이후 60초 타이머 다시 실행
		GetWorldTimerManager().UnPauseTimer(hockey->CountdownTimerHandle60);
		hockey->Emptyscreen();
		
	}
}

//카운트다운이 끝나면
void AHocketpuckSpawner::CountdownHasFinished()
{
	TActorIterator<APlayerPawn>player(GetWorld());
	countdownText->SetText(FText::FromString(TEXT(" ")));
	//퍽생성
	SpawnHockeypuck();
	player->PlayerCanControl = true;
	TActorIterator<AHockeyEnemyChar>enemy(GetWorld());
	enemy->recall();
}

//라운드가 끝나면 (골이 터졌을 경우)
void AHocketpuckSpawner::whenRoundHadEnd()
{
	TActorIterator<APlayerPawn>player(GetWorld());
	player->PlayerCanControl = false;
	player->SetActorLocation(FVector(-750, 0, 0));

	//화면에 5 띄움
	updateTimerdisplay();
	//타이머 작동
	GetWorldTimerManager().SetTimer(CountdownTimerHandle, this, &AHocketpuckSpawner::AdvanceTimer, 1.0f, true);
}

