// Fill out your copyright notice in the Description page of Project Settings.


#include "HockeyPauseWidget.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"
#include "OptionPanelWidget.h"

void UHockeyPauseWidget::PressResumeButton()
{
	UGameplayStatics::SetGamePaused(GetWorld(), false);
}

void UHockeyPauseWidget::PressRetryButton()
{
	UGameplayStatics::SetGamePaused(GetWorld(), false);
	UGameplayStatics::OpenLevel(GetWorld(), "Hockey_map");
}

void UHockeyPauseWidget::PressStopAndExitButton()
{
	UGameplayStatics::SetGamePaused(GetWorld(), false);
	UGameplayStatics::OpenLevel(GetWorld(), "Main");
}

void UHockeyPauseWidget::PressOptionButton()
{
	if (optionPanelWidget != nullptr)
	{
		optionPanelUI = CreateWidget<UOptionPanelWidget>(GetWorld(), optionPanelWidget);
		if (optionPanelUI != nullptr)
		{
			optionPanelUI->AddToViewport();
		}
	}
}

void UHockeyPauseWidget::NativeConstruct()
{
	Super::NativeConstruct();
	RetryButton->OnClicked.AddDynamic(this, &UHockeyPauseWidget::PressRetryButton);
	StopAndExitButton->OnClicked.AddDynamic(this, &UHockeyPauseWidget::PressStopAndExitButton);
	OptionButton->OnClicked.AddDynamic(this, &UHockeyPauseWidget::PressOptionButton);
	ResumeButton->OnClicked.AddDynamic(this, &UHockeyPauseWidget::PressResumeButton);
	XButton->OnClicked.AddDynamic(this, &UHockeyPauseWidget::PressResumeButton);
}
