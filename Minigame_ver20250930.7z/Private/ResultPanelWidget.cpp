// Fill out your copyright notice in the Description page of Project Settings.


#include "ResultPanelWidget.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"

void UResultPanelWidget::goTitle()
{
	UGameplayStatics::SetGamePaused(GetWorld(), false);
	UGameplayStatics::OpenLevel(GetWorld(), "Main");
}

void UResultPanelWidget::NativeConstruct()
{
	Super::NativeConstruct();
	NextStageButton->OnClicked.AddDynamic(this, &UResultPanelWidget::goTitle);
}
