// Fill out your copyright notice in the Description page of Project Settings.


#include "Hockeybase.h"
#include "Blueprint/Userwidget.h"
#include "TimerManager.h"
#include "MainWidget.h"
#include "Components/TextBlock.h"
#include "ResultPanelWidget.h"
#include "Kismet/GameplayStatics.h"
#include "Hockeypuck.h"
#include "EngineUtils.h"
#include "HockeyGoalpost.h"
#include "PlayerPawn.h"
#include "HockeyEnemyChar.h"
#include "HockeyTutorialWidget.h"
#include "OptionPanelWidget.h"

void AHockeybase::PrintScore()
{
	if (mainUI != nullptr)
	{
		mainUI->playerScore->SetText(FText::AsNumber(playerScore));
		mainUI->computerScore->SetText(FText::AsNumber(computerScore));
		mainUI->timer->SetText(FText::AsNumber(RoundTime));
	}
}

//골
void AHockeybase::AddScore(int32 _point)
{
	TActorIterator<AHockeyEnemyChar> Enemy(GetWorld());
	Enemy->EnemyMoveFalse();
	FString whosGoalText;
	switch (_point) //점수 처리 + 누구 골인지 텍스트 입력
	{
	case 1:
		HockeyScore += 10000;
		HockeyScore += RoundTime * 100;
		playerScore++;
		whosGoalText = "Player GOAL !!";
		break;
	case -1:
		HockeyComScore += 5000;
		HockeyComScore += RoundTime * 50;
		computerScore++;
		whosGoalText = "Computer GOAL !!";
		break;
	}

	if (mainUI != nullptr)
	{
		//플레이어 3득점시
		if (playerScore >= 3)
		{
			
			//골 표시 없이, 곧바로 승리 판정
			mainUI->widescreen->SetText(FText::FromString("You Win !!"));
			//라운드타임 초기화, PrintScore로 표시
			RoundTime = 60;
			PrintScore();
			//라운드타임 초 세던것 멈추기
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
			//결과창 출력
			GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::get3score, 3.0f, false, 3.0f);
			/*GetWorldTimerManager().ClearTimer(EmptyTimer);
			GetResultValue();*/

			TActorIterator<AHockeyGoalpost> post(GetWorld());
			//골포스트에게 whenGameEnd 시킴 
			post->whenGameEnd();
		}
		//컴퓨터 3득점시
		else if (computerScore >= 3)
		{
			
			//이하동문
			mainUI->widescreen->SetText(FText::FromString("You Lose..."));
			RoundTime = 60;
			PrintScore();
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
			GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::get3score, 3.0f, false);
			/*GetWorldTimerManager().ClearTimer(EmptyTimer);
			GetResultValue();*/

			TActorIterator<AHockeyGoalpost> post(GetWorld());
			//골포스트에게 whenGameEnd 시킴 
			post->whenGameEnd();
		}
		//아직 누구도 조건 만족X
		else
		{
			//골 표시
			mainUI->widescreen->SetText(FText::FromString(whosGoalText));
			//시간 초기화, 점수 갱신
			RoundTime = 60;
			PrintScore();
			//잠시 퍼즈(HockeyGoalpost.cpp에서 함수 실행하고 진행해줌)
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
			TActorIterator<AHockeyGoalpost> post(GetWorld());
			//골포스트에게 whenGameNotEnd 시킴 (퍽 재생성, 5초 타이머 작동)
			post->whenGameNotEnd();
		}
	}
}

void AHockeybase::updateTimerdisplay60()
{
	mainUI->timer->SetText(FText::AsNumber(RoundTime));
}

void AHockeybase::AdvanceTimer60()
{
	if (RoundTime > 0)
	{
		--RoundTime;
		updateTimerdisplay60();
	}
	if (RoundTime < 1)
	{

		// 카운트다운이 완료되면 타이머를 중지
		
		GetWorldTimerManager().PauseTimer(CountdownTimerHandle60);
		CountdownHasFinished60();
		RoundTime = 60;
	}
}

//60초가 다 지났을 경우 (다른 방식으로 점수 책정)
void AHockeybase::CountdownHasFinished60()
{
	//일단 드로우 출력
	mainUI->widescreen->SetText(FText::FromString("DRAW !!"));
	TActorIterator<AHockeypuck> hockeypuck(GetWorld());
	hockeypuck->groundswitch = false;
	hockeypuck->SetActorLocation(FVector(0, 0, 0));
	TActorIterator<APlayerPawn> player(GetWorld());
	player->PlayerCanControl = false;
	TActorIterator<AHockeyEnemyChar> Enemy(GetWorld());
	Enemy->EnemyMoveFalse();

	//3초후 메시지 변경
	GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::CountdownHasFinished61, 3.0f, false);

}

void AHockeybase::CountdownHasFinished61()
{
	//하키퍽을 통해 각자 땅 점유율 체크
	TActorIterator<AHockeypuck> hockeypuck(GetWorld());
	float playertick = hockeypuck->playergroundtick;
	float computertick = hockeypuck->computergroundtick;

	float playershare = playertick / (playertick + computertick);
	float computershare = computertick / (playertick + computertick);

	//점유율 비교를 출력, 이어서 점수반영
	if (playertick >= computertick)
	{
		FString result = FString::Printf(TEXT("%.1f"), computershare) + " < " + FString::Printf(TEXT("%.1f"), playershare);
		mainUI->widescreen->SetText(FText::FromString(result));
		GetWorldTimerManager().ClearTimer(EmptyTimer);
		GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::CountdownHasFinished62, 3.0f, false);
	}
	else if (computertick >= playertick)
	{
		FString result = FString::Printf(TEXT("%.1f"), computershare) + " > " + FString::Printf(TEXT("%.1f"), playershare);
		mainUI->widescreen->SetText(FText::FromString(result));
		GetWorldTimerManager().ClearTimer(EmptyTimer);
		GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::CountdownHasFinished63, 3.0f, false);
	}

}

void AHockeybase::CountdownHasFinished62()
{
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	AddScore(-1);
}

void AHockeybase::CountdownHasFinished63()
{
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	AddScore(1);
}

//메시지 지우기 (공백상태로 바꿈)
void AHockeybase::Emptyscreen()
{
	mainUI->widescreen->SetText(FText::FromString(""));
}


void AHockeybase::GetResultValue()
{
	if (resultWidget)
	{
		resultUI = CreateWidget<UResultPanelWidget>(GetWorld(), resultWidget);
		if (resultUI)
		{
			resultUI->AddToViewport();
			resultUI->PlayerScore->SetText(FText::AsNumber(playerScore));
			resultUI->ComScore->SetText(FText::AsNumber(computerScore));

			resultUI->hockeyPublicScore->SetText(FText::AsNumber(HockeyScore));
			resultUI->hockeyPublicComScore->SetText(FText::AsNumber(HockeyComScore));
			resultUI->hockeyPublicResultScore->SetText(FText::AsNumber(HockeyScore - HockeyComScore));
			UGameplayStatics::SetGamePaused(GetWorld(), true);
		}
	}
	
}

//실시간 점유율 출력 함수
void AHockeybase::printShare()
{
	TActorIterator<AHockeypuck> hockeypuck(GetWorld());
	if (hockeypuck) {
		float playertick = hockeypuck->playergroundtick;
		float computertick = hockeypuck->computergroundtick;

		float playershare = playertick / (playertick + computertick) * 100;
		float computershare = computertick / (playertick + computertick) * 100;
		//점유율 비교를 출력
		FString playershareString = FString::Printf(TEXT("%.1f"), playershare) + " %";
		FString computershareString = FString::Printf(TEXT("%.1f"), computershare) + " %";

		mainUI->playerGroundShare->SetText(FText::FromString(playershareString));
		mainUI->computerGroundShare->SetText(FText::FromString(computershareString));
	}
}

//결과창 출력 진행 함수
void AHockeybase::get3score()
{
	Emptyscreen();
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	GetResultValue();
}

void AHockeybase::BeginPlay()
{
	Super::BeginPlay();
	HockeyScore = 0;
	HockeyComScore = 0;
	if (mainWidget != nullptr)
	{
		mainUI = CreateWidget<UMainWidget>(GetWorld(), mainWidget);

		if (mainUI != nullptr)
		{
			mainUI->AddToViewport();
		}
	}

	if (optionPanelWidget)
	{
		optionPanelUI = CreateWidget<UOptionPanelWidget>(GetWorld(), optionPanelWidget);
		if (optionPanelUI)
		{
			if (tutorialWidget != nullptr && optionPanelUI->skipTutorialCheck == false)
			{
				tutorialUI = CreateWidget<UHockeyTutorialWidget>(GetWorld(), tutorialWidget);
				if (tutorialUI != nullptr)
				{
					tutorialUI->AddToViewport();
					UGameplayStatics::SetGamePaused(GetWorld(), true);
				}
			}
		}
	}
	GetWorldTimerManager().SetTimer(CountdownTimerHandle60, this, &AHockeybase::AdvanceTimer60, 1.0f, true);
	GetWorldTimerManager().SetTimer(ShareTimer, this, &AHockeybase::printShare, 1.0f, true);
}
