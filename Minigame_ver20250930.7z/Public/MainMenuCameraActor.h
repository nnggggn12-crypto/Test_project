// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraActor.h"
#include "MainMenuCameraActor.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API AMainMenuCameraActor : public ACameraActor
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector XVector = FVector(1, 0, 0);
};
