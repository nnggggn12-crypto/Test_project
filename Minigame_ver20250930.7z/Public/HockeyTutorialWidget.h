// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HockeyTutorialWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UHockeyTutorialWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UHockeyTutorialWidget(const FObjectInitializer &ObjectInitializer);
	
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* HockeyTutorialLeftButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* HockeyTutorialRightButton;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UImage* HockeyTutorialImage;
	TMap<FString, UTexture2D*> TutorialImageMap;



	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 HockeyTutorialImageNumber = 1;

	void pressLeftButton();
	void pressRightButton();
	void changeImageState();
private:
	virtual void NativeConstruct() override;
};
