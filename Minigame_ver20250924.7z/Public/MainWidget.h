// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "MainWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UMainWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* playerScore;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* computerScore;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* timer;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* widescreen;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* playerGroundShare;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* computerGroundShare;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* PauseButton;

	UFUNCTION()
	void PressPauseButton();

	UPROPERTY(EditAnywhere)
	TSubclassOf<class UHockeyPauseWidget> pauseWidget;
	UPROPERTY(EditAnywhere)
	class UHockeyPauseWidget* pauseUI;

private:
	virtual void NativeConstruct() override;
};
