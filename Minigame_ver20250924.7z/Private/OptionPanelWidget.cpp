// Fill out your copyright notice in the Description page of Project Settings.


#include "OptionPanelWidget.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"
#include "MainMenuWidget.h"

void UOptionPanelWidget::CloseOptionPanel()
{
	//mainMenuUI->closeOption();
}

void UOptionPanelWidget::NativeConstruct()
{
	Super::NativeConstruct();
	XButton->OnClicked.AddDynamic(this, &UOptionPanelWidget::CloseOptionPanel);
}
