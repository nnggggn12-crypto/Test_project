// Fill out your copyright notice in the Description page of Project Settings.


#include "HockeyEnemyFSM.h"
#include "Hockeypuck.h"
#include "HockeyEnemyChar.h"
#include <Kismet/GameplayStatics.h>

// Sets default values for this component's properties
UHockeyEnemyFSM::UHockeyEnemyFSM()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UHockeyEnemyFSM::BeginPlay()
{
	Super::BeginPlay();
	auto actor = UGameplayStatics::GetActorOfClass(GetWorld(), AHockeypuck::StaticClass());
	target = Cast<AHockeypuck>(actor);
	me = Cast<AHockeyEnemyChar>(GetOwner());
	// ...
	
}


// Called every frame
void UHockeyEnemyFSM::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	FString logMsg = UEnum::GetValueAsString(mState);
	GEngine->AddOnScreenDebugMessage(0, 1, FColor::Cyan, logMsg);
	// ...
	switch (mState)
	{
	case EEnemyState::Patrol:
		PatrolState();
		break;
	case EEnemyState::Chase:
		ChaseState();
		break;
	case EEnemyState::Attack:
		AttackState();
		break;
	}
}

void UHockeyEnemyFSM::PatrolState()
{
	FVector targetlocation = target->GetActorLocation();
	targetlocation.X = 800;
	FVector dir = targetlocation - me->GetActorLocation();
	me->AddMovementInput(dir.GetSafeNormal());
	if (target->GetActorLocation().X > 0)
	{
		mState = EEnemyState::Chase;
	}
}

void UHockeyEnemyFSM::ChaseState()
{
	FVector targetlocation = target->GetActorLocation();
	FVector dir = targetlocation - me->GetActorLocation();
	dir.X += 50;
	me->AddMovementInput(dir.GetSafeNormal());

	if (target->GetActorLocation().X <= 0)
	{
		mState = EEnemyState::Patrol;
	}
	//else if (dir.X < 50)
	//{
	//	mState = EEnemyState::Attack;
	//}
}

void UHockeyEnemyFSM::AttackState()
{
	FVector targetlocation = target->GetActorLocation();
	FVector dir = targetlocation - me->GetActorLocation();
	FVector dirrev = me->GetActorLocation() - targetlocation;
	me->AddMovementInput(dirrev.GetSafeNormal());
	me->AddMovementInput(dir.GetSafeNormal());
	mState = EEnemyState::Chase;
}

void UHockeyEnemyFSM::reTargetPuck()
{
	auto actor = UGameplayStatics::GetActorOfClass(GetWorld(), AHockeypuck::StaticClass());
	target = Cast<AHockeypuck>(actor);
}

