// Fill out your copyright notice in the Description page of Project Settings.


#include "MainMenuWidget.h"
#include "OptionPanelWidget.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"

void UMainMenuWidget::pressGameStartButton()
{
	UGameplayStatics::OpenLevel(GetWorld(), "Hockey_map");
}

void UMainMenuWidget::pressOptionButton()
{
	if (optionPanelWidget != nullptr)
	{
		optionPanelUI = CreateWidget<UOptionPanelWidget>(GetWorld(), optionPanelWidget);
		if (optionPanelUI != nullptr)
		{
			optionPanelUI->AddToViewport();
		}
	}
}

void UMainMenuWidget::closeOption()
{
	if (optionPanelUI != nullptr)
	{
		optionPanelUI->RemoveFromParent();
	}
}

void UMainMenuWidget::pressQuitButton()
{
	UKismetSystemLibrary::QuitGame(GetWorld(), UGameplayStatics::GetPlayerController(GetWorld(), 0), EQuitPreference::Quit, false);
}

void UMainMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();
	GameStartButton->OnClicked.AddDynamic(this, &UMainMenuWidget::pressGameStartButton);
	QuitButton->OnClicked.AddDynamic(this, &UMainMenuWidget::pressQuitButton);
	OptionButton->OnClicked.AddDynamic(this, &UMainMenuWidget::pressOptionButton);
}
