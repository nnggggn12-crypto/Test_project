// Fill out your copyright notice in the Description page of Project Settings.


#include "Hockeypuck2.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "EngineUtils.h"
#include "PlayerPawn.h"
#include "HockeyEnemyChar.h"


// Sets default values
AHockeypuck2::AHockeypuck2()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	sphereComp = CreateDefaultSubobject<USphereComponent>(TEXT("MyComponent"));
	SetRootComponent(sphereComp);

	meshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MyStaticMesh"));
	meshComp->SetWorldScale3D(FVector(0.6f));
	meshComp->SetupAttachment(sphereComp);

}

// Called when the game starts or when spawn.ed
void AHockeypuck2::BeginPlay()
{
	Super::BeginPlay();
	sphereComp->OnComponentBeginOverlap.AddDynamic(this, &AHockeypuck2::OnPlayerHit);
	computergroundtick = 0.0f;
	playergroundtick = 0.0f;
	groundswitch = true;
}

// Called every frame
void AHockeypuck2::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	FVector myLocation = GetActorLocation() + dir * blockSpeed * DeltaTime;
	myLocation.Z = 0;

	if (myLocation.X >= 950 || myLocation.X <= -950)
	{
		dir.X *= -1;
	}
	if (myLocation.Y >= 530 || myLocation.Y <= -530)
	{
		dir.Y *= -1;
	}

	SetActorLocation(myLocation);

	if (groundswitch)
	{
		if (myLocation.X > 0)
		{
			computergroundtick += 0.1;
		}
		else if (myLocation.X < 0)
		{
			playergroundtick += 0.1;
		}
	}



}

void AHockeypuck2::OnPlayerHit(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	APlayerPawn* player = Cast<APlayerPawn>(OtherActor);
	AHockeyEnemyChar* Enemy = Cast<AHockeyEnemyChar>(OtherActor);

	if (player != nullptr)
	{
		dir = GetActorLocation() - player->GetActorLocation();
		dir.Normalize();
	}
	if (Enemy != nullptr)
	{
		dir = GetActorLocation() - Enemy->GetActorLocation();
		dir.Normalize();
	}
}

void AHockeypuck2::increase_dirX(float _amount)
{
	direction_x = _amount;
}

void AHockeypuck2::increase_dirY(float _amount)
{
	direction_y = _amount;
}

