// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "OptionPanelWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UOptionPanelWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* XButton;

	void CloseOptionPanel();


	UPROPERTY(EditAnywhere)
	TSubclassOf<class UMainMenuWidget> mainMenuWidget;
	UPROPERTY(EditAnywhere)
	class UMainMenuWidget* mainMenuUI;

private:
	virtual void NativeConstruct() override;
};
