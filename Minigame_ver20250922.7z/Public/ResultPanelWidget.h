// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ResultPanelWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UResultPanelWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* NextStageButton;

	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* PlayerScore;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UTextBlock* ComScore;
	UFUNCTION()
	void goTitle();
private:
	virtual void NativeConstruct() override;
};
