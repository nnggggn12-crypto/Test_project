// Fill out your copyright notice in the Description page of Project Settings.


#include "MainMenuGamemodebase.h"
#include "Blueprint/Userwidget.h"
#include "MainMenuWidget.h"

void AMainMenuGamemodebase::BeginPlay()
{
	Super::BeginPlay();
		if (mainMenuWidget != nullptr)
		{
			mainMenuUI = CreateWidget<UMainMenuWidget>(GetWorld(), mainMenuWidget);

			if (mainMenuUI != nullptr)
			{
				mainMenuUI->AddToViewport();
			}
		}
}
