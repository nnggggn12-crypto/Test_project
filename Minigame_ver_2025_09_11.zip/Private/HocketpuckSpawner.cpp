// Fill out your copyright notice in the Description page of Project Settings.


#include "HocketpuckSpawner.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "PlayerPawn.h"
#include "Hockeypuck.h"
#include "Hockeybase.h"

#include "Components/TextBlock.h"

// Sets default values
AHocketpuckSpawner::AHocketpuckSpawner()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	countdownText = CreateDefaultSubobject<UTextRenderComponent>(TEXT("COUNT"));
	countdownText->SetHorizontalAlignment(EHTA_Center);
	countdownText->SetWorldSize(150.0f);
	RootComponent = countdownText;


}

// Called when the game starts or when spawned
void AHocketpuckSpawner::BeginPlay()
{
	Super::BeginPlay();
	countdownText->SetText(FText::FromString(TEXT(" ")));
}

// Called every frame
void AHocketpuckSpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

//��Ű���� 000�� ������Ŵ
void AHocketpuckSpawner::SpawnHockeypuck()
{
	FVector spawnlocation = FVector(0, 0, 0);
	FRotator spawnrotation = FRotator(0, 0, 0);
	FActorSpawnParameters spawnparam;
	spawnparam.bNoFail;
	AActor* spawnActor = GetWorld()->SpawnActor<AActor>(puck, spawnlocation, spawnrotation, spawnparam);
}

//Ÿ�̸� ���÷���(5..4..3..2..1..)
void AHocketpuckSpawner::updateTimerdisplay()
{
	countdownText->SetText(FText::FromString(FString::FromInt(FMath::Max(countdownsec, 0))));
}

//Ÿ�̸� �Լ�
void AHocketpuckSpawner::AdvanceTimer()
{
	--countdownsec;
	updateTimerdisplay();
	if (countdownsec < 1)
	{

		// ī��Ʈ�ٿ��� �Ϸ�Ǹ� Ÿ�̸Ӹ� ����
		GetWorldTimerManager().ClearTimer(CountdownTimerHandle);
		CountdownHasFinished();
		countdownsec = 5;
		TActorIterator<AHockeybase> hockey(GetWorld());
		GetWorldTimerManager().UnPauseTimer(hockey->CountdownTimerHandle60);
		hockey->Emptyscreen();
		
	}
}

//ī��Ʈ�ٿ��� ������
void AHocketpuckSpawner::CountdownHasFinished()
{
	TActorIterator<APlayerPawn>player(GetWorld());
	countdownText->SetText(FText::FromString(TEXT(" ")));
	//�ܻ���
	SpawnHockeypuck();
	player->PlayerCanControl = true;
}

//���尡 ������ (���� ������ ���)
void AHocketpuckSpawner::whenRoundHadEnd()
{
	TActorIterator<APlayerPawn>player(GetWorld());
	player->PlayerCanControl = false;
	player->SetActorLocation(FVector(-750, 0, 0));

	//ȭ�鿡 5 ���
	updateTimerdisplay();
	//Ÿ�̸� �۵�
	GetWorldTimerManager().SetTimer(CountdownTimerHandle, this, &AHocketpuckSpawner::AdvanceTimer, 1.0f, true);
}

