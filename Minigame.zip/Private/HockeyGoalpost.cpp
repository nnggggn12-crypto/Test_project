// Fill out your copyright notice in the Description page of Project Settings.


#include "HockeyGoalpost.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "EngineUtils.h"
#include "Hockeypuck.h"
#include "Kismet/GameplayStatics.h"
#include "Hockeybase.h"
#include "HocketpuckSpawner.h"

// Sets default values
AHockeyGoalpost::AHockeyGoalpost()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	boxComp = CreateDefaultSubobject<UBoxComponent>(TEXT("WallComp"));
	FVector boxsize = FVector(10, 150, 10);
	SetRootComponent(boxComp);
	boxComp->SetBoxExtent(boxsize);

	meshComp = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Wallstaticmesh"));
	meshComp->SetupAttachment(boxComp);
	meshComp->SetWorldScale3D(FVector(0.2, 3.0, 0.2));

	boxComp->SetCollisionProfileName(TEXT("Goalpost"));
}

// Called when the game starts or when spawned
void AHockeyGoalpost::BeginPlay()
{
	Super::BeginPlay();

	boxComp->OnComponentBeginOverlap.AddDynamic(this, &AHockeyGoalpost::OnGoalOverlap);
}

// Called every frame
void AHockeyGoalpost::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

//��
void AHockeyGoalpost::OnGoalOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	AHockeypuck* puck = Cast<AHockeypuck>(OtherActor);

	if (puck != nullptr)
	{
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), Goaleffect, GetActorLocation(), GetActorRotation());
		AGameModeBase* currentMode = GetWorld()->GetAuthGameMode();
		AHockeybase* currentGameModeBase = Cast<AHockeybase>(currentMode);
		if (currentGameModeBase != nullptr)
		{
			int32 point = 0;
			float my_y = GetActorLocation().X;
			float your_y = OtherActor->GetActorLocation().X;
			//������ ����
			puck->groundswitch = false;
			//�������
			if (my_y <= 0)
			{
				currentGameModeBase->AddScore(-1);
			}
			else
			{
				currentGameModeBase->AddScore(1);
			}

			//������ �ȳ����� �� �ߵ�
			if (currentGameModeBase->playerScore != 3 && currentGameModeBase->computerScore != 3)
			{
				OtherActor->Destroy();
				TActorIterator<AHocketpuckSpawner> spawner(GetWorld());
				spawner->whenRoundHadEnd();
			}
		}

		
	}
}

