// Fill out your copyright notice in the Description page of Project Settings.


#include "Hockeybase.h"
#include "Blueprint/Userwidget.h"
#include "TimerManager.h"
#include "MainWidget.h"
#include "Components/TextBlock.h"
#include "ResultPanelWidget.h"
#include "Kismet/GameplayStatics.h"
#include "Hockeypuck.h"
#include "EngineUtils.h"

void AHockeybase::PrintScore()
{
	if (mainUI != nullptr)
	{
		mainUI->playerScore->SetText(FText::AsNumber(playerScore));
		mainUI->computerScore->SetText(FText::AsNumber(computerScore));
		mainUI->timer->SetText(FText::AsNumber(RoundTime));
	}
}

//��
void AHockeybase::AddScore(int32 _point)
{
	switch (_point) //���� ó��
	{
	case 1:
		playerScore++;
		break;
	case -1:
		computerScore++;
		break;
	}

	if (mainUI != nullptr)
	{
		//�÷��̾� 3������
		if (playerScore >= 3)
		{
			mainUI->widescreen->SetText(FText::FromString("You Win !!"));
			RoundTime = 60;
			PrintScore();
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
			GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::get3score, 3.0f, false, 3.0f);
			/*GetWorldTimerManager().ClearTimer(EmptyTimer);
			GetResultValue();*/
		}
		//��ǻ�� 3������
		else if (computerScore >= 3)
		{
			mainUI->widescreen->SetText(FText::FromString("You Lose..."));
			RoundTime = 60;
			PrintScore();
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
			GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::get3score, 3.0f, false);
			/*GetWorldTimerManager().ClearTimer(EmptyTimer);
			GetResultValue();*/
		}
		//���� ������ ���� ����X
		else
		{
			//�� ǥ��
			mainUI->widescreen->SetText(FText::FromString("GOAL !!"));
			//�ð� �ʱ�ȭ, ���� ����
			RoundTime = 60;
			PrintScore();
			//��� ����(HockeyGoalpost.cpp���� �Լ� �����ϰ� ��������)
			GetWorld()->GetTimerManager().PauseTimer(CountdownTimerHandle60);
		}
	}
}

void AHockeybase::updateTimerdisplay60()
{
	mainUI->timer->SetText(FText::AsNumber(RoundTime));
}

void AHockeybase::AdvanceTimer60()
{
	--RoundTime;
	updateTimerdisplay60();
	if (RoundTime < 1)
	{

		// ī��Ʈ�ٿ��� �Ϸ�Ǹ� Ÿ�̸Ӹ� ����
		GetWorldTimerManager().ClearTimer(CountdownTimerHandle60);
		CountdownHasFinished60();
		RoundTime = 60;
	}
}

//60�ʰ� �� ������ ��� (�ٸ� ������� ���� å��)
void AHockeybase::CountdownHasFinished60()
{
	//�ϴ� ��ο� ���
	mainUI->widescreen->SetText(FText::FromString("DRAW !!"));
	
	//3���� ��ο� �޽��� ����
	GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::Emptyscreen, 3.0f, false);
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	//��Ű���� ���� ���� �� ������ üũ
	TActorIterator<AHockeypuck> hockeypuck(GetWorld());
	float playertick = hockeypuck->playergroundtick;
	float computertick = hockeypuck->computergroundtick;
	
	float playershare = playertick / (playertick + computertick);
	float computershare = computertick / (playertick + computertick);

	//������ �񱳸� ���
	FString result = FString::SanitizeFloat(computershare) + " : " + FString::SanitizeFloat(playershare);
	mainUI->widescreen->SetText(FText::FromString(result));
	//���� 3���� �޽��� ����
	GetWorldTimerManager().SetTimer(EmptyTimer, this, &AHockeybase::Emptyscreen, 3.0f, false);
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	//�׸��� ���� �ݿ�
	if (playertick >= computertick)
	{
		AddScore(-1);
	}
	else if (computertick >= playertick)
	{
		AddScore(1);
	}

}

void AHockeybase::Emptyscreen()
{
	mainUI->widescreen->SetText(FText::FromString(""));
}


void AHockeybase::GetResultValue()
{
	if (resultWidget)
	{
		resultUI = CreateWidget<UResultPanelWidget>(GetWorld(), resultWidget);
		if (resultUI)
		{
			resultUI->AddToViewport();
			resultUI->PlayerScore->SetText(FText::AsNumber(playerScore));
			resultUI->ComScore->SetText(FText::AsNumber(computerScore));
			UGameplayStatics::SetGamePaused(GetWorld(), true);
		}
	}
	
}

void AHockeybase::printShare()
{
	TActorIterator<AHockeypuck> hockeypuck(GetWorld());
	if (hockeypuck) {
		float playertick = hockeypuck->playergroundtick;
		float computertick = hockeypuck->computergroundtick;

		float playershare = playertick / (playertick + computertick) * 100;
		float computershare = computertick / (playertick + computertick * 100);
		playershare = printf("%.2f", playershare);
		//������ �񱳸� ���
		FString playershareString = FString::SanitizeFloat(playershare) + " %";
		FString computershareString = FString::SanitizeFloat(computershare) + " %";

		mainUI->playerGroundShare->SetText(FText::FromString(playershareString));
		mainUI->computerGroundShare->SetText(FText::FromString(computershareString));
	}
}

void AHockeybase::get3score()
{
	Emptyscreen();
	GetWorldTimerManager().ClearTimer(EmptyTimer);
	GetResultValue();
}

void AHockeybase::BeginPlay()
{
	Super::BeginPlay();
	if (mainWidget != nullptr)
	{
		mainUI = CreateWidget<UMainWidget>(GetWorld(), mainWidget);

		if (mainUI != nullptr)
		{
			mainUI->AddToViewport();
		}
	}
	GetWorldTimerManager().SetTimer(CountdownTimerHandle60, this, &AHockeybase::AdvanceTimer60, 1.0f, true);
	GetWorldTimerManager().SetTimer(ShareTimer, this, &AHockeybase::printShare, 1.0f, true);
}
