// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Hockeybase.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API AHockeybase : public AGameModeBase
{
	GENERATED_BODY()
private:
	int32 FirstCountDown = 5;
	int32 RoundTime = 60;
	void PrintScore();

public:
	void AddScore(int32 _point);
	UPROPERTY(EditAnywhere)
	TSubclassOf<class UMainWidget> mainWidget;
	UPROPERTY(EditAnywhere)
	class UMainWidget* mainUI;
	void updateTimerdisplay60();

	void AdvanceTimer60();

	void CountdownHasFinished60();
	
	UPROPERTY(EditAnywhere)
	FTimerHandle CountdownTimerHandle60;

	UFUNCTION()
	void Emptyscreen();

	FTimerHandle EmptyTimer;

	//������ ����..?
	UPROPERTY(EditAnywhere)
	TSubclassOf<class UResultPanelWidget> resultWidget;
	UPROPERTY(EditAnywhere)
	class UResultPanelWidget* resultUI;
	void GetResultValue();

	UPROPERTY(EditAnywhere)
	int32 playerScore = 0;
	UPROPERTY(EditAnywhere)
	int32 computerScore = 0;

	UFUNCTION()
	void printShare();
	FTimerHandle ShareTimer;


	void get3score();
protected:
	virtual void BeginPlay() override;
};
