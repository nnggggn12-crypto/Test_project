// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "MainMenuWidget.generated.h"

/**
 * 
 */
UCLASS()
class MINIGAME_API UMainMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* GameStartButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* OptionButton;
	UPROPERTY(EditAnywhere, meta = (BindWidget))
	class UButton* QuitButton;

	UFUNCTION()
	void pressGameStartButton();
	UFUNCTION()
	void pressOptionButton();
	UFUNCTION()
	void closeOption();
	UFUNCTION()
	void pressQuitButton();

	UPROPERTY(EditAnywhere)
	TSubclassOf<class UOptionPanelWidget> optionPanelWidget;
	UPROPERTY(EditAnywhere)
	class UOptionPanelWidget* optionPanelUI;

private:
	virtual void NativeConstruct() override;
};
